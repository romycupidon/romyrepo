import base64 as b

id   = 'plugin.video.myiptv'

name = '[COLOR orangered]MyIPTV[/COLOR]'

